# Coy Discover — SDE Intern Assignment (Part B)

A mobile-first, standalone **React + Express** swipe app demonstrating a privacy-first mutual matching experience. Built for the supplied Coy SDE Intern Assignment. This is an **unofficial assignment demo**, not Coy's actual application.

## Features

- `Home` and `Discover` main tabs. **Home is intentionally blank**, as requested.
- Discover contains an `Explore` view and a `Matches` view.
- **30 fictional profiles** with local placeholder portraits, ages, bios, cities/colleges and interests.
- Swipe left/right on mobile or press Pass/Like buttons on desktop.
- Smooth card animations and an empty state when no profiles remain.
- Six profiles have pre-seeded incoming likes; liking one causes an immediate **It's a match!** modal.
- Incoming likes are **never sent to the frontend** unless a mutual match is created.
- Swipes and matches persist to a local JSON file across page reloads and server restarts.
- Duplicate swipes rejected with HTTP 409.
- Automated backend tests with Node's built-in test runner.
- A ready-to-import Postman collection (`Coy_Discover_Postman_Collection.json`).

## Requirements

- **Node.js 20+** (recommend Node 22 LTS) and npm.
- VS Code (optional).
- Two terminal windows.

No MySQL, Docker, OTP login, email service or paid API is required for Part B.

## 1. Run the backend

Open this folder in VS Code, then run in **Terminal 1**:

```powershell
cd backend
npm install
npm run dev
```

The backend should print `Coy API running at http://localhost:4000`.

## 2. Run the frontend

Open **Terminal 2** from the `coy-discover` root:

```powershell
cd frontend
npm install
npm run dev
```

Open the local URL displayed by Vite (usually `http://localhost:5173`).

> In VS Code, if you are already inside `backend` and want to switch to frontend, run `cd ..` first.

## 3. Demo it

1. Open the Discover tab (default).
2. The **first profile** already has a private incoming like in the backend's mock data. Press the pink Heart button to see the match modal.
3. Click **View matches** to see the first mutual match.
4. Return to Explore, swipe left/right and refresh the page.
5. Previous profiles do not return, and matches remain saved.
6. Swipe through all 30 profiles to reach the empty state.

To reset the demo, stop or leave the backend running and use a terminal in the `backend` folder:

```powershell
npm run reset
```

Then refresh the browser.

## API contract

The backend uses exactly the requested routes (no `/api` prefix):

### `GET /feed`

Returns an array of public profiles that have not been swiped.

### `POST /swipe`

Example request body:

```json
{ "profileId": 1, "action": "like" }
```

`action` is either `like` or `pass`.

If there is no mutual match:

```json
{ "matched": false }
```

If both users liked each other:

```json
{
  "matched": true,
  "match": {
    "id": 1,
    "name": "Aanya",
    "age": 22,
    "photo": "/avatars/1.svg",
    "bio": "Collecting little moments, sunset walks, and books with bent corners.",
    "location": "Delhi University",
    "interests": ["Books", "Coffee", "Travel"]
  }
}
```

A duplicate swipe returns HTTP 409 and an error message. Validation errors return HTTP 400, missing profiles return HTTP 404.

### `GET /matches`

Returns an array containing **mutual matches only**.

### Example PowerShell commands

```powershell
Invoke-RestMethod -Uri http://localhost:4000/feed -Method Get
Invoke-RestMethod -Uri http://localhost:4000/swipe -Method Post -ContentType 'application/json' -Body '{"profileId":1,"action":"like"}'
Invoke-RestMethod -Uri http://localhost:4000/matches -Method Get
```

## Postman testing

Import `Coy_Discover_Postman_Collection.json` in Postman. The `baseUrl` collection variable defaults to `http://localhost:4000`. Run the requests in order: GET feed, POST swipe, GET matches. Reset the backend data to replay the like example.

## Backend tests

From `backend`:

```powershell
npm test
```

Tests cover: 30 profiles and required fields, no incoming-like leaks, no matches from passes, mutual-like logic, never re-showing swiped profiles, duplicate prevention, persistence and API responses.

## Architecture

```text
coy-discover/
├── frontend/
│   ├── public/avatars/         # 30 local illustrated photo placeholders
│   ├── src/App.jsx             # Tabs, swipe UI, match modal, Matches view
│   ├── src/api.js              # HTTP client
│   ├── src/styles.css          # Responsive styling
│   └── vite.config.js          # Dev proxy for backend routes
├── backend/
│   ├── server.js               # Express API
│   ├── src/domain.js           # Feed, swipe, mutual matching and privacy logic
│   ├── src/seed.js             # Fictional profile data + private incoming likes
│   ├── src/storage.js          # Atomic JSON persistence
│   ├── test/domain.test.js     # Automated backend tests
│   ├── scripts/reset.js        # Re-seed demo data
│   └── data/store.json         # Generated automatically; gitignored
└── README.md
```

## Privacy considerations

- The internal `incomingLikeIds` list stays on the **server** and is never included in `/feed` or `/matches` responses unless a profile has become a mutual match.
- `publicProfile()` explicitly whitelists fields to prevent accidental disclosure of new internal properties.
- `/matches` lists only profiles with both an incoming like and an explicit outgoing `like`.
- A pass never generates a match, even if the other user liked first.
- No authentication is needed because the assignment explicitly assumes one logged-in user.
- This is a **local single-process demo**. For production, replace JSON persistence with a transactional database and implement authentication, authorization, rate limiting, moderation and multi-user match integrity.

## GitHub submission

1. Create a new **public** repo named `coy-discover` on GitHub.
2. In the project root, run:

```powershell
git init
git add .
git commit -m "Build privacy-first Coy Discover assignment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/coy-discover.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your real GitHub username. Commit source files, not `node_modules`, generated `dist`, or `data/store.json`.

## Optional deployment

For a deployed demo, host `frontend` and `backend` separately, configure `VITE_API_BASE_URL` to the deployed backend URL **at frontend build time**, and restrict CORS to your deployed frontend origin. Local execution and a public GitHub repository meet the explicit assignment instructions; deployment is optional.
