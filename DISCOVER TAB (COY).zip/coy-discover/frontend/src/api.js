const base = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${base}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...options.headers }
    });
  } catch {
    throw new Error('Cannot reach the API. Start the backend in a separate terminal on port 4000.');
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status}).`);
  return body;
}

export const api = {
  feed: () => request('/feed'),
  matches: () => request('/matches'),
  swipe: (profileId, action) => request('/swipe', {
    method: 'POST', body: JSON.stringify({ profileId, action })
  })
};
