import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useMotionValue, useTransform } from 'framer-motion';
import {
  ArrowRight, Check, Compass, Heart, Home, LockKeyhole,
  MapPin, RotateCcw, ShieldCheck, Sparkles, X
} from 'lucide-react';
import { api } from './api.js';

function ProfileCard({ profile, direction, onSwipe, disabled }) {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-250, 0, 250], [-15, 0, 15]);
  const likeOpacity = useTransform(x, [20, 100], [0, 1]);
  const passOpacity = useTransform(x, [-100, -20], [1, 0]);

  function onDragEnd(_event, info) {
    if (disabled) return;
    const distance = info.offset.x;
    const speed = info.velocity.x;
    if (distance > 110 || speed > 650) onSwipe('like');
    else if (distance < -110 || speed < -650) onSwipe('pass');
  }

  return (
    <motion.article
      className="profile-card"
      style={{ x, rotate, touchAction: 'pan-y' }}
      drag={!disabled ? 'x' : false}
      dragDirectionLock
      dragElastic={0.8}
      dragMomentum={false}
      onDragEnd={onDragEnd}
      custom={direction}
      initial={{ opacity: 0, scale: 0.94, y: 18 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={(swipeDirection) => ({
        x: swipeDirection === 'like' ? 560 : -560,
        rotate: swipeDirection === 'like' ? 25 : -25,
        opacity: 0,
        transition: { duration: 0.35, ease: 'easeOut' }
      })}
      transition={{ type: 'spring', stiffness: 320, damping: 30 }}
      aria-label={`${profile.name}, ${profile.age}, ${profile.location}`}
    >
      <img src={profile.photo} alt={`Illustrated placeholder portrait of ${profile.name}`} draggable="false" />
      <div className="card-shade" />
      <motion.div className="swipe-stamp stamp-like" style={{ opacity: likeOpacity }}>LIKE <Heart size={26}/></motion.div>
      <motion.div className="swipe-stamp stamp-pass" style={{ opacity: passOpacity }}>PASS <X size={26}/></motion.div>
      <div className="profile-content">
        <div className="profile-meta"><span className="active-dot"/> OPEN TO CONNECT</div>
        <h2>{profile.name}<span>, {profile.age}</span></h2>
        <p className="location"><MapPin size={15}/> {profile.location}</p>
        <p className="bio">{profile.bio}</p>
        <div className="interest-tags">
          {profile.interests.map((interest) => <span key={interest}>{interest}</span>)}
        </div>
      </div>
    </motion.article>
  );
}

function MatchDialog({ profile, onClose, onMatches }) {
  useEffect(() => {
    const onKey = (event) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <motion.div className="modal-backdrop" role="presentation" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div className="match-modal" role="dialog" aria-modal="true" aria-label={`It's a match with ${profile.name}`}
        initial={{ scale: 0.8, y: 40 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0 }}>
        <button className="modal-close" onClick={onClose} aria-label="Close match popup"><X size={20}/></button>
        <div className="confetti confetti-a"/><div className="confetti confetti-b"/><div className="confetti confetti-c"/>
        <div className="match-hearts"><Heart size={47} fill="currentColor"/></div>
        <span className="eyebrow">THE FEELING IS MUTUAL</span>
        <h2>It's a match!</h2>
        <img className="matched-portrait" src={profile.photo} alt={`Illustrated portrait of ${profile.name}`} />
        <p>You and <strong>{profile.name}</strong> both liked each other. Some things are better when they're mutual.</p>
        <button className="button button-primary modal-action" onClick={onMatches}>View matches <ArrowRight size={18}/></button>
        <button className="text-button" onClick={onClose}>Keep discovering</button>
      </motion.div>
    </motion.div>
  );
}

function MatchesView({ matches, onExplore }) {
  return (
    <div className="matches-area">
      <div className="view-heading"><span className="eyebrow">THE RIGHT KIND OF SPARK</span><h2>Your matches <span>{matches.length}</span></h2>
        <p>Only people who liked you back appear here.</p></div>
      {matches.length > 0 ? (
        <div className="matches-grid">
          {matches.map((profile) => <article className="match-card" key={profile.id}>
            <img src={profile.photo} alt={`Illustrated portrait of ${profile.name}`} />
            <div className="match-card-content"><div className="matched-label"><Check size={13}/> MUTUAL LIKE</div>
              <h3>{profile.name}, {profile.age}</h3><p><MapPin size={13}/> {profile.location}</p></div>
          </article>)}
        </div>
      ) : (
        <div className="empty-box"><div className="empty-symbol"><Heart size={38}/></div>
          <h3>Your story is just beginning</h3>
          <p>When you and someone like each other, your mutual match appears here. Your privacy stays protected.</p>
          <button className="button button-primary" onClick={onExplore}>Discover people <ArrowRight size={18}/></button>
        </div>
      )}
    </div>
  );
}

function EmptyFeed({ onMatches }) {
  return (
    <div className="empty-box finished"><div className="empty-symbol"><Sparkles size={42}/></div>
      <span className="eyebrow">YOU'RE ALL CAUGHT UP</span><h2>You've met everyone.</h2>
      <p>No profiles left for now. Your past swipes are saved, so nobody will show up again after a refresh.</p>
      <button className="button button-primary" onClick={onMatches}>See your matches <ArrowRight size={18}/></button>
      <small>For a fresh demo, run <code>npm run reset</code> in the backend folder and refresh.</small>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState('discover');
  const [view, setView] = useState('discover');
  const [feed, setFeed] = useState([]);
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [direction, setDirection] = useState('like');
  const [newMatch, setNewMatch] = useState(null);
  const busyRef = useRef(false);

  useEffect(() => {
    let active = true;
    Promise.all([api.feed(), api.matches()])
      .then(([profiles, mutual]) => {
        if (active) { setFeed(profiles); setMatches(mutual); setError(''); }
      })
      .catch((err) => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  async function handleSwipe(action) {
    const profile = feed[0];
    if (!profile || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setError('');
    try {
      const result = await api.swipe(profile.id, action);
      setDirection(action);
      setFeed((current) => current.filter((candidate) => candidate.id !== profile.id));
      if (result.matched) {
        setMatches((existing) => existing.some((item) => item.id === result.match.id) ? existing : [...existing, result.match]);
        setNewMatch(result.match);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  function openMatches() { setNewMatch(null); setTab('discover'); setView('matches'); }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand" aria-label="Coy demo"><div className="brand-mark"><Heart size={21} fill="currentColor"/></div> coy<span>.</span></div>
        <nav className="topnav" aria-label="Main navigation">
          <button onClick={() => setTab('home')} className={`nav-item ${tab === 'home' ? 'active' : ''}`}><Home size={18}/> Home</button>
          <button onClick={() => { setTab('discover'); setView('discover'); }} className={`nav-item ${tab === 'discover' ? 'active' : ''}`}><Compass size={18}/> Discover</button>
        </nav>
        <div className="demo-badge"><span className="active-dot"/> DEMO MODE</div>
      </header>

      {tab === 'home' ? <main className="blank-home" aria-label="Blank Home tab"/> : (
        <main className="main-layout">
          <aside className="side-panel">
            <div className="pill"><Sparkles size={14}/> DISCOVER SOMETHING REAL</div>
            <h1>The best things<br/>start with a <em>spark.</em></h1>
            <p>Meet new people, find shared interests, and see what happens when the feeling is mutual.</p>
            <div className="promise-card">
              <div className="promise-icon"><LockKeyhole size={22}/></div>
              <div><strong>Private by design</strong><p>No one knows who liked them unless the feeling goes both ways.</p></div>
            </div>
            <div className="how-to"><span>HOW IT WORKS</span><p><X size={16}/> Swipe left to pass</p><p><Heart size={16}/> Swipe right to like</p><p><Sparkles size={16}/> Mutual likes make a match</p></div>
            <div className="side-footer"><ShieldCheck size={17}/> Your choices stay yours.</div>
          </aside>

          <section className="content-panel">
            <div className="content-heading">
              <div><span className="eyebrow">YOUR SPACE TO CONNECT</span><h2>Discover <span>✦</span></h2></div>
              <div className="tabs" role="tablist" aria-label="Discover views">
                <button role="tab" aria-selected={view === 'discover'} className={view === 'discover' ? 'selected' : ''} onClick={() => setView('discover')}><Compass size={16}/> Explore</button>
                <button role="tab" aria-selected={view === 'matches'} className={view === 'matches' ? 'selected' : ''} onClick={openMatches}><Heart size={16}/> Matches <span className="count">{matches.length}</span></button>
              </div>
            </div>

            {error && <div className="error-banner" role="alert">{error}</div>}
            {loading ? <div className="loading"><RotateCcw className="spin" size={28}/><p>Finding your people...</p></div>
              : view === 'matches' ? <MatchesView matches={matches} onExplore={() => setView('discover')}/>
                : <div className="explore-area">
                    {feed.length > 0 ? <>
                      <div className="feed-top"><span>{feed.length} {feed.length === 1 ? 'person' : 'people'} to discover</span><span><LockKeyhole size={13}/> Only mutual likes are revealed</span></div>
                      <div className="card-wrap"><div className="card-underlay"/>
                        <AnimatePresence mode="popLayout" custom={direction}>
                          {feed[0] && <ProfileCard key={feed[0].id} profile={feed[0]} direction={direction} disabled={busy} onSwipe={handleSwipe}/>}
                        </AnimatePresence>
                      </div>
                      <div className="swipe-controls">
                        <button aria-label="Pass on this profile" className="circle-button pass-button" onClick={() => handleSwipe('pass')} disabled={busy}><X size={27}/></button>
                        <div className="control-hint">{busy ? 'SAVING YOUR CHOICE…' : 'SWIPE OR TAP TO CHOOSE'}</div>
                        <button aria-label="Like this profile" className="circle-button like-button" onClick={() => handleSwipe('like')} disabled={busy}><Heart size={27} fill="currentColor"/></button>
                      </div>
                    </> : <EmptyFeed onMatches={openMatches}/>}
                  </div>}
          </section>
        </main>
      )}

      <nav className="mobile-nav" aria-label="Mobile navigation">
        <button className={tab === 'home' ? 'active' : ''} onClick={() => setTab('home')}><Home size={20}/> Home</button>
        <button className={tab === 'discover' ? 'active' : ''} onClick={() => { setTab('discover'); setView('discover'); }}><Compass size={20}/> Discover</button>
      </nav>

      <AnimatePresence>{newMatch && <MatchDialog key={newMatch.id} profile={newMatch} onClose={() => setNewMatch(null)} onMatches={openMatches}/>}</AnimatePresence>
    </div>
  );
}
