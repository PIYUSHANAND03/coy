import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/feed': 'http://localhost:4000',
      '/swipe': 'http://localhost:4000',
      '/matches': 'http://localhost:4000'
    }
  }
});
