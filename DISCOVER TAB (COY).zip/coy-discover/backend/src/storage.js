const fs = require('node:fs');
const path = require('node:path');
const { createFreshState } = require('./seed');

const DEFAULT_DB_PATH = path.join(__dirname, '..', 'data', 'store.json');

function writeState(state, dbPath = DEFAULT_DB_PATH) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const temporaryPath = `${dbPath}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(state, null, 2), 'utf8');
  fs.renameSync(temporaryPath, dbPath);
}

function readState(dbPath = DEFAULT_DB_PATH) {
  if (!fs.existsSync(dbPath)) writeState(createFreshState(), dbPath);
  return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
}

module.exports = { DEFAULT_DB_PATH, readState, writeState };
