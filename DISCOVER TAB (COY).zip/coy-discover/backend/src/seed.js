// Entirely fictional demo profiles. Inbound likes are server-side fixture data.
const people = [
  ['Aanya', 22, 'Delhi University', 'Collecting little moments, sunset walks, and books with bent corners.', ['Books', 'Coffee', 'Travel']],
  ['Arjun', 24, 'Bengaluru', 'Weekend football, weekday debugging. Will always say yes to dosa.', ['Football', 'Coding', 'Food']],
  ['Meera', 21, 'Mumbai', 'Film photography and finding the best tiny cafés in town.', ['Photography', 'Art', 'Cafés']],
  ['Rohan', 23, 'IIT Delhi', 'Guitar in hand, mountains on my mind, playlists for every season.', ['Music', 'Hiking', 'Dogs']],
  ['Diya', 22, 'Pune', 'Curious soul with a soft spot for rainy days and museums.', ['Museums', 'Dance', 'Reading']],
  ['Kabir', 25, 'Hyderabad', 'Chef in progress. I make an excellent biryani (sources: me).', ['Cooking', 'Cycling', 'Movies']],
  ['Ishita', 23, 'Jaipur', 'Design student. I notice beautiful fonts and cloud shapes.', ['Design', 'Travel', 'Art']],
  ['Aarav', 22, 'BITS Pilani', 'Board games, astronomy, and questionable science jokes.', ['Science', 'Gaming', 'Coffee']],
  ['Sana', 24, 'Chandigarh', 'A playlist for every road trip and a camera for every stop.', ['Road Trips', 'Music', 'Photography']],
  ['Dev', 21, 'Ahmedabad', 'Here for good conversations and better street food.', ['Food', 'Cricket', 'Podcasts']],
  ['Tara', 23, 'Kolkata', 'Painting what I cannot put into words.', ['Painting', 'Poetry', 'Cats']],
  ['Neil', 26, 'Chennai', 'Running routes, indie films, and old vinyl records.', ['Running', 'Cinema', 'Music']],
  ['Nisha', 20, 'SRCC Delhi', 'Learning languages and chasing the next big adventure.', ['Languages', 'Travel', 'Books']],
  ['Vihaan', 24, 'Lucknow', 'Tech, tennis, and long conversations after midnight.', ['Tennis', 'Technology', 'Tea']],
  ['Zoya', 22, 'Noida', 'An amateur baker with professional snack standards.', ['Baking', 'Music', 'Dogs']],
  ['Aditya', 25, 'Gurugram', 'Fitness by morning, sketching by night.', ['Fitness', 'Sketching', 'Travel']],
  ['Anika', 21, 'Manipal', 'Ocean person learning to love the mountains too.', ['Beaches', 'Volleyball', 'Films']],
  ['Reyansh', 23, 'Indore', 'Always up for a game night or a spontaneous trek.', ['Games', 'Trekking', 'Food']],
  ['Priya', 24, 'Varanasi', 'Interested in philosophy, pottery, and being kind.', ['Pottery', 'Philosophy', 'Yoga']],
  ['Samir', 22, 'NIT Trichy', 'Learning to make music and incredible pasta.', ['Piano', 'Cooking', 'Chess']],
  ['Riya', 23, 'Bhopal', 'A little bit of sunshine and a lot of curiosity.', ['Nature', 'Books', 'Dance']],
  ['Kunal', 25, 'Kochi', 'Coffee first, kayaking second, everything else later.', ['Kayaking', 'Coffee', 'Travel']],
  ['Aditi', 22, 'Amity University', 'Concerts and cozy bookstores are my happy places.', ['Concerts', 'Books', 'Fashion']],
  ['Yash', 24, 'Goa', 'Waves, surfboards, and playlists with too many songs.', ['Surfing', 'Music', 'Nature']],
  ['Simran', 21, 'Patiala', 'Dance enthusiast exploring every cuisine I can find.', ['Dance', 'Cooking', 'Travel']],
  ['Om', 23, 'Surat', 'Big fan of small adventures, cinema, and Sunday brunch.', ['Cinema', 'Cycling', 'Brunch']],
  ['Maya', 22, 'New Delhi', 'Storyteller collecting memories one city at a time.', ['Writing', 'Travel', 'Art']],
  ['Harsh', 26, 'Mumbai', 'I make terrible puns and really good playlists.', ['Music', 'Comedy', 'Running']],
  ['Kiara', 23, 'Bengaluru', 'Plant parent, amateur photographer, full-time dreamer.', ['Plants', 'Photos', 'Food']],
  ['Eshan', 24, 'Dehradun', 'Mountains are home. Always looking for a new trail.', ['Hiking', 'Nature', 'Coffee']]
];

const PROFILES = people.map(([name, age, location, bio, interests], index) => ({
  id: index + 1,
  name,
  age,
  photo: `/avatars/${index + 1}.svg`,
  bio,
  location,
  interests
}));

function createFreshState() {
  return {
    profiles: structuredClone(PROFILES),
    // PRIVATE: never include this array in API payloads or frontend data.
    incomingLikeIds: [1, 5, 9, 14, 20, 27],
    swipes: []
  };
}

module.exports = { PROFILES, createFreshState };
