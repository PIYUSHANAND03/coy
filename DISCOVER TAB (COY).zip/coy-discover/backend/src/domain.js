// Keep public fields explicit: a newly added internal field cannot leak by accident.
function publicProfile(profile) {
  return {
    id: profile.id,
    name: profile.name,
    age: profile.age,
    photo: profile.photo,
    bio: profile.bio,
    location: profile.location,
    interests: profile.interests
  };
}

function getFeed(state) {
  const swipedIds = new Set(state.swipes.map((swipe) => swipe.profileId));
  return state.profiles.filter((profile) => !swipedIds.has(profile.id)).map(publicProfile);
}

function getMatches(state) {
  const incomingLikes = new Set(state.incomingLikeIds);
  const mutualIds = new Set(
    state.swipes
      .filter((swipe) => swipe.action === 'like' && incomingLikes.has(swipe.profileId))
      .map((swipe) => swipe.profileId)
  );
  return state.profiles.filter((profile) => mutualIds.has(profile.id)).map(publicProfile);
}

class SwipeError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.name = 'SwipeError';
    this.status = status;
  }
}

function recordSwipe(state, profileId, action) {
  if (!Number.isInteger(profileId)) {
    throw new SwipeError('profileId must be an integer.');
  }
  if (action !== 'like' && action !== 'pass') {
    throw new SwipeError('action must be "like" or "pass".');
  }

  const profile = state.profiles.find((item) => item.id === profileId);
  if (!profile) throw new SwipeError('Profile not found.', 404);
  if (state.swipes.some((swipe) => swipe.profileId === profileId)) {
    throw new SwipeError('You have already swiped on this profile.', 409);
  }

  state.swipes.push({ profileId, action, createdAt: new Date().toISOString() });
  const matched = action === 'like' && state.incomingLikeIds.includes(profileId);
  return matched ? { matched: true, match: publicProfile(profile) } : { matched: false };
}

module.exports = { publicProfile, getFeed, getMatches, recordSwipe, SwipeError };
