const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createFreshState } = require('../src/seed');
const { getFeed, getMatches, recordSwipe } = require('../src/domain');
const { readState, writeState } = require('../src/storage');

test('feed begins with 30 fictional profiles and includes required public fields', () => {
  const feed = getFeed(createFreshState());
  assert.equal(feed.length, 30);
  for (const profile of feed) {
    for (const key of ['id', 'name', 'age', 'photo', 'bio', 'location', 'interests']) {
      assert.ok(Object.hasOwn(profile, key), `missing ${key}`);
    }
  }
});

test('backend never exposes private incoming likes in feed', () => {
  const feed = getFeed(createFreshState());
  assert.ok(feed.every((profile) => !('incomingLikeIds' in profile) && !('likedMe' in profile)));
});

test('a pass cannot create a match, even if the other user liked first', () => {
  const state = createFreshState();
  assert.deepEqual(recordSwipe(state, 1, 'pass'), { matched: false });
  assert.deepEqual(getMatches(state), []);
});

test('right swipe makes a match only for mutual likes', () => {
  const state = createFreshState();
  assert.equal(recordSwipe(state, 2, 'like').matched, false);
  const result = recordSwipe(state, 1, 'like');
  assert.equal(result.matched, true);
  assert.equal(result.match.id, 1);
  assert.deepEqual(getMatches(state).map((p) => p.id), [1]);
});

test('swiped profiles never appear in the feed again', () => {
  const state = createFreshState();
  recordSwipe(state, 1, 'like');
  recordSwipe(state, 2, 'pass');
  const ids = getFeed(state).map((profile) => profile.id);
  assert.equal(ids.length, 28);
  assert.ok(!ids.includes(1) && !ids.includes(2));
});

test('duplicate swipes, unknown profiles, and invalid actions are rejected', () => {
  const state = createFreshState();
  assert.throws(() => recordSwipe(state, 999, 'like'), { status: 404 });
  assert.throws(() => recordSwipe(state, 1, 'yes'), { status: 400 });
  assert.throws(() => recordSwipe(state, '1', 'like'), { status: 400 });
  recordSwipe(state, 1, 'like');
  assert.throws(() => recordSwipe(state, 1, 'pass'), { status: 409 });
});

test('swipes and mutual matches survive persistence to JSON', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'coy-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const dbPath = path.join(dir, 'store.json');
  const state = readState(dbPath);
  recordSwipe(state, 1, 'like');
  recordSwipe(state, 3, 'pass');
  writeState(state, dbPath);
  const reloaded = readState(dbPath);
  assert.equal(reloaded.swipes.length, 2);
  assert.deepEqual(getMatches(reloaded).map((p) => p.id), [1]);
  assert.equal(getFeed(reloaded).length, 28);
});

test('API routes return feed, match status and mutual matches without leaking incoming likes', async (t) => {
  const { createApp } = require('../server');
  let state = createFreshState();
  const app = createApp({ read: () => structuredClone(state), write: (updated) => { state = updated; } });
  const server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  t.after(() => server.close());
  const base = `http://127.0.0.1:${server.address().port}`;
  const feedResp = await fetch(`${base}/feed`);
  const feed = await feedResp.json();
  assert.equal(feed.length, 30);
  assert.ok(!JSON.stringify(feed).includes('incomingLikeIds'));
  const swipeResp = await fetch(`${base}/swipe`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ profileId: 1, action: 'like' })
  });
  assert.equal(swipeResp.status, 200);
  assert.equal((await swipeResp.json()).matched, true);
  const matches = await (await fetch(`${base}/matches`)).json();
  assert.deepEqual(matches.map((p) => p.id), [1]);
  const feedAgain = await (await fetch(`${base}/feed`)).json();
  assert.equal(feedAgain.length, 29);
  const duplicate = await fetch(`${base}/swipe`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ profileId: 1, action: 'like' })
  });
  assert.equal(duplicate.status, 409);
});
