const express = require('express');
const cors = require('cors');
const { readState, writeState } = require('./src/storage');
const { getFeed, getMatches, recordSwipe, SwipeError } = require('./src/domain');

function createApp({ read = readState, write = writeState } = {}) {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '10kb' }));

  app.get('/feed', (_req, res) => {
    res.json(getFeed(read()));
  });

  app.post('/swipe', (req, res, next) => {
    try {
      const state = read();
      const result = recordSwipe(state, req.body?.profileId, req.body?.action);
      write(state);
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  app.get('/matches', (_req, res) => {
    res.json(getMatches(read()));
  });

  app.use((err, _req, res, _next) => {
    if (err instanceof SwipeError) {
      return res.status(err.status).json({ error: err.message });
    }
    if (err instanceof SyntaxError && 'body' in err) {
      return res.status(400).json({ error: 'Invalid JSON request body.' });
    }
    console.error(err);
    res.status(500).json({ error: 'Internal server error.' });
  });
  return app;
}

if (require.main === module) {
  const port = Number(process.env.PORT) || 4000;
  createApp().listen(port, () => console.log(`Coy API running at http://localhost:${port}`));
}

module.exports = { createApp };
