const { createFreshState } = require('../src/seed');
const { writeState } = require('../src/storage');
writeState(createFreshState());
console.log('Demo data reset: 30 profiles, zero swipes, zero matches.');
